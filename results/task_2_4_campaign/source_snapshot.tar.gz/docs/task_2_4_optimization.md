# Task 2.4: circuit-aware readout optimization

<!-- Final numerical summary is generated after the convergence audit. -->

## Purpose and comparison

Increasing the memory drive makes the buffer signal larger, but it can also
cause the memory to change codeword. We test that trade-off in the full
memory–buffer master equation, then enlarge the cat during readout so that a
stronger signal can coexist with stronger protection. The memory is returned
to its original size after measurement.

Two reference rates are kept distinct: undriven storage at the supplied
$\alpha_0=2.1$, and the existing Task 2.3 readout at
$\epsilon_Z/g_2=0.05$. A reduction relative to weak readout does not, by itself,
mean that the undriven storage rate is preserved.

## Circuit derivation: drive, phase and surviving terms

We use $\hbar=1$, time in µs, and angular frequencies in µs⁻¹. The operators
$a$ and $b$ annihilate a memory and buffer photon. The illustrative circuit is

$$
H_{\mathrm{circuit}}=\omega_a a^\dagger a+\omega_b b^\dagger b
-2E_J\cos\varphi_\Sigma\cos(\Phi+\varphi_\Delta),\qquad
\Phi=\varphi_a(a+a^\dagger)+\varphi_b(b+b^\dagger).
$$

The zero-point phases are $\varphi_a=0.06$, $\varphi_b=0.30$;
$E_J/(2\pi)=40$ GHz, $\omega_a/(2\pi)=4$ GHz and
$\omega_b/(2\pi)=4.8$ GHz. The pump frequency is
$\omega_p=2\omega_a-\omega_b$, with
$\epsilon_p=0.0353241$ rad fixed by
$g_2=E_J\epsilon_p\varphi_a^2\varphi_b/2$.
These are the challenge's illustrative parameters, rather than a fit to a
particular fabricated device.

### A physical memory-drive port

A calibrated microwave force coupled to the memory adds

$$
H_{Z,\mathrm{lab}}=2\epsilon_Z(t)\cos(\omega_a t+\theta)(a+a^\dagger).
$$

The voltage-to-force conversion is absorbed into $\epsilon_Z$. In the frame
rotating at $\omega_a$, its resonant part is

$$
H_Z=\epsilon_Z(t)(e^{i\theta}a+e^{-i\theta}a^\dagger).
$$

Thus $\theta=0$ gives the real drive used in Task 2.3. Its counter-rotating
terms oscillate at $2\omega_a$. A capacitive port couples to the charge
quadrature; shifting its microwave phase gives the convention above.
The buffer drive is supplied through its own microwave port. The memory
readout drive is an external control term in the circuit Hamiltonian, rather
than a consequence of changing the two-photon pump amplitude alone.

### First-order pump rotating-wave approximation

At the stated ATS bias, the pump interaction is
$2E_J\epsilon_p\cos(\omega_p t)\sin\Phi$. Expanding
$\sin\Phi=\Phi-\Phi^3/6+\Phi^5/120-\cdots$ produces a negative cubic exchange
at the printed pump phase. We shift that phase by π and choose the buffer
phase consistently, obtaining the positive $g_2$ convention used throughout
this repository:

$$
H_{\mathrm{RWA}}=g_2(a^2b^\dagger+a^{\dagger2}b)
-\epsilon_d(b+b^\dagger)+H_Z.
$$

The linear pump forces and the other cubic monomials are off resonance.
There is no static Kerr term at this first-order, odd-potential operating
point. Fifth-order phase terms do survive at the same exchange resonance:

$$
H_{\mathrm{ex}}^{(5)}=
 g_2\left(1-\frac{\varphi_a^2+\varphi_b^2}{2}\right)a^2b^\dagger
-\frac{g_2\varphi_a^2}{3}a^\dagger a^3b^\dagger
-\frac{g_2\varphi_b^2}{2}a^2b^{\dagger2}b+\mathrm{h.c.}
$$

They renormalize the exchange and make it occupation dependent. We also
retain all powers of $\Phi$ at the fundamental pump harmonic. For the Fock
transition $|n,m\rangle\to|n-2,m+1\rangle$, write its matrix element as
$g_2\sqrt{n(n-1)(m+1)}F_{n,m}$. Then

$$
F_{n,m}=\frac{2J_1(\epsilon_p)}{\epsilon_p}
 e^{-(\varphi_a^2+\varphi_b^2)/2}
 \frac{2L_{n-2}^{(2)}(\varphi_a^2)}{n(n-1)}
 \frac{L_m^{(1)}(\varphi_b^2)}{m+1}.
$$

Here $J_1$ is a Bessel function and $L_n^{(k)}$ is an associated Laguerre
polynomial. Direct matrix polynomials and matrix sines independently check
these coefficients. The buffer drive is recalibrated so that its coherent
exchange expectation vanishes at the chosen real target amplitude; retaining
the cubic value $\epsilon_d=g_2\alpha^2$ after changing the exchange would
silently change the target cat size.

### Off-resonant pump terms

Fast terms can have a small amplitude relative to GHz frequencies yet produce
important corrections on the MHz and rare-switching scales. For
$H(t)=H_0+\sum_{\Omega>0}(H_\Omega e^{i\Omega t}+\mathrm{h.c.})$, the leading
van-Vleck correction is

$$
H_{\mathrm{VV}}^{(2)}=
\sum_{\Omega>0}\frac{[H_\Omega,H_\Omega^\dagger]}{\Omega}.
$$

We retain every contribution through sixth order in the zero-point phases.
In particular, cubic×cubic and linear×fifth terms must both be included;
keeping only the former gives inconsistent Kerr coefficients. Fourth phase
order produces frequency shifts. Sixth order additionally produces

$$
H_K=K_a n_a(n_a-1)+K_b n_b(n_b-1)+\chi n_a n_b,
\qquad n_a=a^\dagger a,\quad n_b=b^\dagger b.
$$

The constant and linear frequency shifts are calibrated away. To preserve the
local target wells, the memory and buffer frequencies also track the mean
Kerr shifts $2K_a\alpha^2$ and $\chi\alpha^2$. Their residual fluctuations remain
in the simulation. All terms in this consistent sixth-order correction are
diagonal; a resonant two-pump exchange requires higher phase order.

<!-- CIRCUIT_COEFFICIENT_TABLE -->

This is a systematically truncated effective-Hamiltonian calculation at the stated order,
not an exact open-system simulation of the GHz circuit. Higher-order
Hamiltonian terms, bath dressing, flux noise and fabrication uncertainties
are not silently included in its error certificate. The all-phase diagonal
van-Vleck calculation is a sensitivity check, since it omits higher-order
off-diagonal processes.

The circuit and drive conventions follow the supplied challenge; the fuller
ATS Hamiltonian and pump calibration are documented in
[Réglade et al., Supplement S3–S4](https://arxiv.org/html/2307.06617v2#S4).

## Drive-strength trade-off

Let $\rho_s(t)$ be the joint state initialized in
$|s\alpha\rangle_a|0\rangle_b$, $s=\pm1$, and
$\beta_s(t)=\mathrm{Tr}[b\rho_s(t)]$. Contrast is the real separation of the
3–4 µs means, $\Delta\beta_R=\mathrm{Re}(\bar\beta_--\bar\beta_+)$.
These are finite-window, initial-codeword-dependent signals.

We define $\Gamma_X$ from the slow decay of the difference between the two
initial-codeword evolutions, using the same observable-rate convention as
Task 2.1. In a two-state description,
$\Gamma_X=k_{+\to-}+k_{-\to+}$; it equals twice either one-way rate only when
those rates are equal. Kerr corrections can break that symmetry.

<!-- TRADEOFF_TABLE_AND_FIGURE -->

At weak drive, the added switching rate is approximately quadratic in
$\epsilon_Z$. The physical mechanism is leakage from the protected manifold
followed by stabilization into either well. Increasing the drive therefore
buys signal at a cost in switching. The one-mode second-order theory of
[Dubovitskii, Table I](https://arxiv.org/html/2407.17299v2#S2.T1) explains the
$\epsilon_Z^2e^{-2\alpha^2}$ dependence; its prefactor is not substituted for
the full two-mode numerical rate. In that adiabatic weak-drive limit,

$$
\dot{\mathcal I}\simeq\frac{4\epsilon_Z^2}{\kappa_2\alpha^2},\qquad
\Gamma_{X,\mathrm{drive}}\simeq
\frac{4\epsilon_Z^2}{\kappa_2\alpha^2}e^{-2\alpha^2}.
$$

Here $\kappa_2=4g_2^2/\kappa_b$, and the second expression uses the observable
relaxation convention, twice the symmetric one-way rate. Increasing drive
alone therefore leaves the leading information-per-flip ratio unchanged;
increasing cat separation improves it exponentially. The supplied parameters
are not in the fast-buffer limit, so this motivates the strategy while the
full two-mode calculations determine its performance.

## Strategy: enlarge, read, restore

Enlarging the cat alone reduces the buffer contrast, since
$\Delta\beta_R\simeq\epsilon_Z/(\alpha g_2)$. The useful combination is to
increase the separation and then apply a stronger readout drive. The larger
separation suppresses switching while the stronger drive increases the signal.

The storage amplitude is $\alpha_0=2.1$. The tested sequence is:

1. With the memory drive off, smoothly increase the buffer drive so that the
   target amplitude rises to $\alpha_{\mathrm{ro}}=2.6$.
2. Apply the readout drive at the enlarged amplitude.
3. Turn off the memory drive, return the target to $\alpha_0$, and allow the
   same final relaxation interval as the reference protocol.

The ramps use $f(u)=10u^3-15u^4+6u^5$, $0\leq u\leq1$, so their first two
endpoint derivatives vanish. For the cubic model,
$\epsilon_d(t)=g_2\alpha(t)^2$; the circuit models use the calibrated exchange
expectation. All supplied loss channels remain active throughout.

### A common information target

For an ideal vacuum-limited homodyne reference, define

$$
\mathcal I(T)=\kappa_b\int_0^T
 [\mathrm{Re}(\beta_-(t)-\beta_+(t))]^2\,\mathrm{d}t.
$$

We require $\mathcal I=\mathcal I_*=1$ at the end of the readout-drive interval.
The reported total cycle duration additionally includes amplification, return
and final relaxation. Post-switch-off emission is excluded from the information
budget. This is a **conditional-mean signal functional**, not a claim
of measured classification fidelity. Under coherent Gaussian output and
unit efficiency it corresponds to an error of 15.9%, not 1%. Detector
inefficiency and complete measurement-record statistics are not inferred from
mean fields. A quantum-regression calculation separately checks the local
output-noise covariance. Circuit cases can optimize a fixed homodyne phase
rather than assuming the signal remains in the original real quadrature.

### Memory disturbance after return

We use an orthonormal logical basis built from normalized even and odd cats,
$|0_L\rangle=(|C_+\rangle+|C_-\rangle)/\sqrt2$ and
$|1_L\rangle=(|C_+\rangle-|C_-\rangle)/\sqrt2$, at $\alpha_0$.
For each initial sign we report the final wrong-codeword population and the
population outside this two-dimensional code space. Neither is renormalized
by postselection. The worse of the two initial signs is used for comparisons.
These quantities measure stored-bit disturbance; they are distinct from the
readout's classification error.

<!-- CYCLE_RESULTS_AND_FIGURES -->

### Circuit mitigation

<!-- BALANCED_CIRCUIT_RESULTS -->

A small intentional junction imbalance supplies a circuit-native static
cosine potential. Define $E_J=(E_{J1}+E_{J2})/2$ and
$\Delta E_J=(E_{J1}-E_{J2})/2$. Writing the extra ATS term as
$2\Delta E_J\sin\varphi_\Sigma\sin(\Phi+\varphi_\Delta)$ gives a mean term
$C\cos\Phi$, with $C=-2\Delta E_JJ_0(\epsilon_p)$ at the chosen bias.
Its leading Kerr additions are

$$
\delta K_a=\frac{C\varphi_a^4}{4},\qquad
\delta K_b=\frac{C\varphi_b^4}{4},\qquad
\delta\chi=C\varphi_a^2\varphi_b^2.
$$

Choosing $C=-\chi/(\varphi_a^2\varphi_b^2)$ cancels the leading cross-Kerr.
This is an explicit hardware modification with frequency recalibration,
rather than a free compensating Hamiltonian. Its usefulness is judged from
both residual Kerr coefficients and the full corrected dynamics, not from the
cancellation formula alone.

## What did not solve the whole problem

A two-step input shaper can cancel an underdamped signal mode without raising
the peak memory drive. It does not remove the common memory-loss transient,
and reduced ringing does not automatically increase accumulated information.
We therefore distinguish field settling from measurement speed and use the
complete information-and-disturbance comparison above to choose a strategy.

<!-- INPUT_SHAPING_RESULTS -->

## Numerical methods and verification

Rates come from full two-mode Liouvillian eigenmodes, with independent
full-complex QuTiP time-domain fits. Both codeword initial conditions are
integrated for the readout and complete cycles. Cutoff tests include rare
switching rates themselves: small top-level populations alone do not certify
an exponentially small error rate. Numerical residuals and cutoff differences
are retained in the saved data.

For the real cubic and number-dependent exchange models, a π/2 rotation of
both modes makes the Hamiltonian imaginary and the initial codeword difference
imaginary antisymmetric. Packing that invariant sector is an exact change of
representation. Kerr corrections couple it to the real symmetric sector, so
the corrected calculation retains the complete traceless Hermitian density
matrix. Tests compare both representations with independently constructed
full-complex generators.

<!-- VALIDATION_TABLE -->

## Costs and scope

The proposed control requires a calibrated buffer-drive ramp, a stronger
memory-drive pulse and a return ramp. Larger cats store more photons and
increase memory-loss phase-flip dephasing. During a measurement of the
codeword sign, that dephasing is expected; it is nevertheless a physical cost.
The corrected hardware proposal additionally requires controlled junction
imbalance and frequency calibration. It is a proof of principle within the
explicit effective models, rather than a fabrication-ready device guarantee.

<!-- REPRODUCTION_AND_DATA -->
