# Task 2.4 numerical/cloud audit

Independent read-only audit for the cloud orchestration session, 2026-10-25.
Existing maintained source remains owned by the ongoing Task 2.4 implementation.
Audit evidence lives here, not in maintained source or production results.

## Hardware and concurrency recommendation

Choose one dedicated AMD **16-vCPU / 64-GB RAM** VM with local NVMe. Parent's
observed VX1 960-GB local-storage plan is $0.612/h; that is a pricing observation,
not a performance measurement. A CPU VM fits the current implementations better
than a GPU: sparse SuperLU/METIS/ARPACK is CPU code, independent QuTiP BDF is CPU,
and Dynamiqs solves modest double-precision density matrices. No GPU speedup has
been benchmarked. Large GPUs are not justified by the current evidence.

A 32x12 density matrix is 384x384, only 2.36 MB complex128, but integration stages,
JAX compilation and eigensolver factors dominate RAM. Existing independent
METIS factorization for its 73,536-dimensional strict-antisymmetric Liouvillian
has **176,174,744 L+U nonzeros**: about 2.1 GB just for real values plus int32
indices, before SuperLU workspaces and copies. Local factorization took134.0s;
COLAMD examples took~860s. Do not infer cloud timing from those local timings.
Larger cutoffs and full Hermitian corrected generators can consume much more.

Start with **six quantum workers, each bound to two disjoint logical CPUs**, one
spectral worker bound to one or two CPUs, and two CPUs reserved for the OS and
orchestrator. Set OMP_NUM_THREADS, OPENBLAS_NUM_THREADS, MKL_NUM_THREADS and
NUMEXPR_NUM_THREADS=1. Bind affinity before importing JAX; CPU affinity is more
reliable than assuming an XLA flag caps every compiler/runtime pool. Keep large
spectral concurrency1 until measured peak RSS supports2. Give 32x12 spectral
jobs an initial16-GB reservation and corrected/full generators24–32GB. Increase
parallelism from observed resource use rather than enabling16 unconstrained
Python processes. Measure /usr/bin/time -v per case on Linux.

The existing capstone jobs are still running locally. Avoid duplicating them
before collecting their completed outputs. As inspected, tasks/task_2_4.py
contains helper functions but no main/CLI, so running it as a module alone does
not start the intended research campaign. A separate campaign entry point is
required until the owning implementation adds its executable main.

## Executed bounded benchmarks

Python3.12 validated env; BLAS/OpenMP caps1; no existing source modified. Both
benchmarks used one readout drive and independently evolved both codewords,
0–0.25us,51 output times, alpha2.1. These are performance smoke tests, not new
physics claims. The source/configuration metadata is in the benchmark logs.

| Cutoff / tolerances | Integration wall | Total callable wall | Process peak RSS |
|---|---:|---:|---:|
|24x8 /1e-9,1e-11|5.920s|12.610s|591,839,232 bytes|
|32x12 /1e-10,1e-12|15.279s|21.225s|693,518,336 bytes|

Files: benchmark.py, benchmark.log, benchmark32.py, benchmark32.log and
benchmark_cache/. The tests used fresh processes and finished within the85s
and65s safety timeouts. Machine reports18 logical CPUs. No linear extrapolation
of these short runs to cloud cost, long times or large factorization is valid.

## Scientific issues to resolve before headline claims

1. **Measurement normalization.** Under dY=2sqrt(eta*kappa)Re(e^-iphi beta)dt+dW,
   define I=eta*kappa integral[Re(e^-iphi Delta beta)]²dt. Current measurement
   helpers return I. The matched-filter squared mean separation in unit-noise
   standard deviations is **d-prime²=4I**, matching the user's displayed SNR².
   In the equal white-Gaussian reference, Perror=Phi(-sqrt(I)); I=1 means15.87%
   error, not1%. Export I and d-prime² explicitly. QuTiP's official current
   convention confirms J=<S+Sdag>+dW/dt:
   https://qutip.readthedocs.io/en/stable/guide/dynamics/dynamics-stochastic.html
   Connected covariance diagnostics are useful, but a local stationary boxcar
   variance is not the nonstationary optimally weighted full-cycle distribution.

2. **Fair optimizer comparator.** Alpha2.6/drive0.25 versus alpha2.1/drive0.05
   is not sufficient to establish improvement against a tuned constant pulse.
   Include constant drives0.05,0.10,0.15,0.25,0.5 at common I and full-cycle time,
   then compare recovered wrong population/leakage and the Pareto frontier.
   Show readout-only, first-control-to-read-end and complete-cycle clocks
   separately. Return/reset time belongs in the complete-cycle comparison.

3. **Current spectral acceleration is not wired into bit_spectrum.** As read,
   bit_spectrum still calls ARPACK directly with sigma, invoking default LU.
   src/spectral.factor_shifted supplies validated METIS acceleration but must be
   passed as OPinv explicitly by the caller. Do not silently bypass its
   backward-error checks to obtain a faster answer.

4. **A nearest-shift k=1 mode is not a dominance certificate.** Selected jobs
   should compute4–6 nearby modes, use several shifts/orderings, check residuals
   against the original generator and check observable/initial-state overlaps.
   Left/right eigenvector conditioning matters: tiny residual alone is not a
   quantitative error bound on a rare rate. Direct time-domain comparisons at
   smaller alpha and a driven physical-target case are already feasible in the
   existing evidence. Save fits versus initial fit window. Report unresolved
   rates or shifts as unresolved rather than extrapolating precise digits.

5. **The real antisymmetric sector has a restricted domain.** It is exact for
   real readout drive and the retained real exchange model, as independently
   tested by dense physical generators. General microwave phase, detuning,
   diagonal Kerr/Stark terms or other circuit corrections can couple it to the
   symmetric sector. These require a validated full complex or full Hermitian
   trace-zero generator. Corrected static rates may be asymmetric; GammaX is
   the sum of forward and reverse rates only when a two-state model is valid.

6. **Logical population and leakage.** The implemented cat projectors are
   correctly orthonormalized. Keep wrong population, leakage and deterministic
   amplitude changes separate. Coherent initial states have a small baseline
   wrong-projector weight; report initial/idle reference values. During cat-size
   amplification, the fixed storage-alpha projector labels intentional motion
   as storage-code leakage. Use that projector for FINAL recovered leakage,
   and an instantaneous-target code projector for any transient leakage bound.
   Do not call a temporary storage-code mismatch an unwanted bit flip.

7. **Missing pulse family coverage.** Current cycle() controls cat-size ramps
   with a rectangular memory readout. It does not yet implement the user's
   Gaussian, raised-cosine or shaped/depletion memory pulses. Queuing only its
   amplification cycles would not execute all proposed strategies. Add those
   controls in an isolated module or the owner's implementation, then validate
   drive edges exactly and compare equal constraints. The earlier input-shaper
   pilot reduces settling0.968→0.666us but may sacrifice information; compare
   integrated signal and cycle error before calling it better readout.

## Recommended prioritized campaign manifest

P0 — environment and model smoke checks:
- Run physical tests for circuit, measurement, rate sector and factorization.
- Store Python/platform/BLAS/JAX/QuTiP/SciPy versions, hardware and source snapshot.
- Repeat short32x12 benchmark on cloud before enabling the full worker pool.

P1 — executed broad baseline, fast cases before optimizer:
- fields(alpha=2.1 and2.6, ratios=[0,.05,.10,.25,.5,1],32x12,end4us).
- Static spectra at alpha=[.9,1.2,1.4,2.1,2.6], ratios=[0,.05,.10,.25,.5,1].
  Use20x6 only for exploratory small cats,28x10 exploratory physical cats;
  validate selected physical cases at32x12 and separate larger cutoffs.
- Full cycle alpha_storage2.1, alpha_readout2.1, ramp0, idle2us, same drive grid;
  use information targetsI=[.25,1] and adapt read duration from executed signals.
  Do not infer final logical error from Gamma*T alone.

P2 — fair short-control exploration:
- At fixed alpha2.1, compare rectangular, raised-cosine, Gaussian and quintic
  ramp/plateau memory drives with common amplitude/bandwidth limits.
- Optimize a low-dimensional2–4-segment amplitude envelope; include a signed
  termination segment for buffer depletion. Keep fixed real phase initially,
  then test a phase-shaped candidate with full complex dynamics.
- Separately test temporary alpha_readout=[2.3,2.6,2.8], drive=[.1,.25,.5],
  ramp=[.5,1,2]us. Measure COMPLETE cycle duration and recovered storage errors.
- Use semiclassical candidate ranking first, then full32x12 quantum evaluation.
  Freeze finalists before reporting convergence; optimizer success is not proof.

P3 — validation budget concentrated on baseline +2 finalists:
- Cutoffs32x12→40x12,32x14,40x14 separately/jointly; check trajectory metrics,
  wrong population, leakage and high-Fock populations, not contrast alone.
- Tighten ODE tolerance10x and saved spacing2x; split exact pulse boundaries.
- Independent QuTiP32x12 cubic cycle, both initial states, same stage durations.
- Static-rate k4–6, shifts1e-8/1e-9/1e-10, original-generator residuals, overlap
  and small-alpha fit checks. Keep these jobs in the spectral resource lane.
- Robustness alpha/drive phase/coupling/kappa_b ±2% and ±5% on finalists.
- Apply circuit corrections to baseline AND finalists using the same calibrated
  convention; report failures or loss of advantage honestly.

Every case needs a stable physics/settings/source hash; atomic result writes;
status queued/running/completed/failed with timestamps; exit code, logs, wall
and peak RSS; save grids/complex fields/populations, controls, error definitions,
initial/final projectors and cutoff checks. Bound the campaign wall time and
leave an explicit stop/status command. A worker crash must not turn an incomplete
NPZ or a stale cache hit into a successful scientific result.

## Implemented spectral lane follow-up

At parent's request, added only `src/readout_campaign_spectrum.py` and
`tests/test_campaign_spectrum.py`. API:

```python
summary, arrays = analyze_spectrum(
    Na=32, Nb=12, alpha=2.1, ratio=.25,
    shift=1e-8, k=4, ordering='auto', time_check=False)
```

The helper uses the checked METIS/COLAMD inverse explicitly, retains all four
near-shift modes, checks residuals against the original packed generator and
normalizes modal coefficients using matched left/right eigenvectors. Finite
ARPACK lists can end on one member of a conjugate pair; left conjugates are
completed exactly for the real matrix, and right-list conjugate closure is
reported explicitly. The slowest memory-visible returned mode is only a
candidate. `global_dominance_certified` remains false. A visible zero/unstable
or heuristically unresolved slow mode is not silently replaced by a faster
negative eigenvalue. A resolution heuristic based on residual and eigenvector
conditioning is recorded as a heuristic, not a formal rare-rate bound.

Optional full-sector Radau checks are restricted to Na*Nb<=64, with an explicit
10,000-us maximum horizon. They retain both normalized memory amplitude and
orthonormal logical imbalance, and fit three late-time windows. Missing or
insufficiently changed signals are marked unresolved. These are deterministic
fit diagnostics rather than statistical uncertainties.

All five tests pass in0.319s, including direct agreement with an independently
built unrotated complex Lindblad generator, complete dense-eigensystem modal
coefficients, time-domain fits, an early large-system check rejection and a
closed unitary system that must not acquire a spurious decay rate. Initial
strict all-mode coefficient testing exposed a truncated conjugate pair in real
ARPACK output; conjugate completion fixed that genuine bookkeeping issue.
One test invocation used a mistyped virtualenv path and exited127; the corrected
final command and results are in `campaign_spectrum_tests.log`.

Independent runner review flagged process cleanup after exceptions, stale
starting statuses, STOP-file semantics, final stopped/deadline status, orphan
worker protection, saved waveform knot fidelity and adaptive-proposal ordering.
It also recommended keeping non-dominated error/information/depletion candidates
and matched-duration constant comparators, and explicitly withholding full
circuit-correction certification for the resonant-sine sensitivity alone.

## Scheduler regression coverage follow-up

Added only `tests/test_campaign_runner.py`, using standard-library fake processes
and temporary files. Seven tests pass (no production simulations and no real
subprocesses): smoke campaigns cannot expand into production; source drift is
rejected by scheduler and worker; exit before a valid summary is failed even
with exit code zero; deadline termination and SIGKILL escalation clear active
workers; unexpected scheduler errors clean up worker groups; semiclassical
proposals must receive quantum evidence before finalist freeze; duplicate case
IDs are rejected and matching constant comparators remain available.

This testing exposed/confirmed a duplicate-validation race when a matched
constant comparator and selected constant finalist create the same case ID.
The runner owner fixed deduplication while the regression test was developed.
Remaining review advice: close the scheduler lock handle explicitly; catch
ProcessLookupError if a worker exits between polling and sending the signal;
retain explicit graceful semantics for STOP or change it to immediate stopping.
These tests check process-control behavior with fakes, not a proof against OS
SIGKILL or machine loss; a systemd cgroup/time limit provides a useful second
layer. Evidence: campaign_runner_tests.log.
