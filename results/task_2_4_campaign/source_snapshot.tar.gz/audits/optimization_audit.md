# Independent optimization and comparison audit

Scope: read-only review of current Task 2.4 helpers, report draft and pilot evidence. No production run or cloud action performed. Existing source is owned by the original capstone session. Dedicated Task 2.4 README is the only maintained file owned by this audit agent.

## Immediate findings

1. `tasks/task_2_4.py` presently ends at `cycle_metrics`; it has no main or argument parser. Its advertised module command imports and exits. Parent is preparing `tasks/task_2_4_campaign.py` as the actual resumable launcher.
2. Existing cycle control ramps the buffer drive (target alpha), while the memory readout drive is rectangular. It does not yet implement the user-requested Gaussian, raised-cosine readout-drive, or controlled-depletion profiles.
3. The proposed amplified cycle alpha2.6/epsilonZ=.25g2 is compared with a weak alpha2.1/.05g2 constant reference. This demonstrates improvement over that particular reference but cannot establish an optimized advantage over constant drive. A fixed-alpha2.1 constant sweep at the same maximum drive and same information target is required.
4. The independent readout checks are substantial: saved equal-I amplified cycles match independently constructed QuTiP evolutions at shared stage boundaries. They are pilot evidence, not completion of the new broader constrained optimization campaign.
5. Measurement normalization: for dY=2sqrt(eta*kappa_b)Re[e^(-i phi)B_s]dt+dW, the squared distance of conditional mean records in unit white noise is D^2=4*eta*kappa_b*integral(Re[e^(-i phi)DeltaB]^2)dt. The current I functional is D^2/4, so equal-I comparisons are valid. I=1 corresponds to Phi(-1)=15.87% classification error ONLY in the coherent, equal-white-Gaussian-noise reference; it is not a measured fidelity. Fixed-LO Gram-matrix optimization is the appropriate mean-signal metric if the corrected circuit rotates the pointer fields.

## A simple defensible campaign

Keep alpha_storage=2.1, all supplied rates, identical drive-amplitude constraints, identical numerical tolerances, the same homodyne efficiency/LO assumption, and the same information window across the main shape comparison. Define T_active from first nonzero control to final control termination; T_cycle additionally includes a recovery interval whose stopping tolerance is shared by all candidates. Do not call the read-drive duration the complete readout cycle.

Use the full two-mode model for every promoted candidate. The semiclassical equations can cheaply screen candidates and provide starts but cannot certify rare logical flips or final leakage.

### Tier 1: tuned constant baseline

Use epsilonZ/g2 in .05,.10,.25,.50 (optionally1.0 as stress test), and active windows 2,4,8,16us to map fixed-time I versus worst-branch final wrong population/leakage/residual buffer excitation. Where an information target is bracketed, solve for the shortest matching duration with a scalar bracket search, then verify the root with a full two-mode pulse-and-recovery run. For the .05 case, infer an initial long-window guess from the 3–4us slope, but execute the full duration before claiming its result.

A Pareto curve across constant amplitudes is the reference. The earlier .05 benchmark remains useful for continuity but is not the sole comparator.

### Tier 2: smooth edges

At fixed alpha, compare rectangular, raised-cosine ramp–plateau–ramp, and Gaussian memory-drive envelopes. Use smooth widths and equal T_active, peak drive bound and information budget. Gaussian pulses do not have mathematically finite support, so specify truncation/offset/window and ensure endpoints are exactly the declared values. Charge lost turn-on/off signal against the smooth pulse; a visually smoother transient alone is not a gain.

Use ramp fractions .05,.10,.20,.35 and coarse amplitude grid, then bounded scalar/coordinate refinement. This is easy to explain and audit, avoiding an opaque high-dimensional optimizer.

### Tier 3: build/hold/deplete

Use three real signed control segments with finite smooth edges: build positive drive, hold information-producing drive, then a bounded negative-drive segment to cancel residual memory–buffer motion. Parameterize amplitudes by u1,u2,u3 in [-u_max,u_max], and two independent duration fractions with a fixed total active window. A negative real envelope is a pi-phase flip of the same microwave line; no time-dependent LO rotation is required. Start with real pulses to preserve simple symmetry and reduce parameter count. Complex phase-shaped controls are a separate extension requiring an explicitly implemented I/Q quadrature Hamiltonian and phase-calibration assumption.

Optimize inexpensive semiclassical candidates with bounded multistart coordinate search; retain 5–10 diverse candidates rather than one nominal optimum. Verify these quantum mechanically and use that feedback for a final low-dimensional refinement. Penalize residual *total buffer photons* relative to the idle-storage baseline, not merely |<b>|^2: incoherent photons survive cancellation of the mean field.

### Separate axis: enlarge/read/restore

The existing alpha2.6 strategy is scientifically promising because it can improve information per induced switching event, rather than only reducing ringing. Treat amplification as an additional control resource. Compare against tuned constant alpha2.1 at equal information and total cycle time; include up/down ramps, additional pump power, increased photon-loss dephasing and code-space recovery. Do not define transient leakage relative to storage-alpha code space and then interpret coherent, intentional enlargement as an error without separately reporting the moving-code-space diagnostic.

## Objectives and acceptance

Report a Pareto front in (T_cycle, I_end, max_branch_wrong_population, max_branch_final_leakage, buffer_excess_after_recovery). Candidate constraints should be declared before selecting a winner. Example numerical design thresholds for a pilot are not universal physics tolerances and must be labelled as chosen. If no pulse beats the tuned constant frontier within validation error, retain the negative finding.

Use all readout photons within the same declared collection window. If post-switch-off emission is excluded, exclude it for every profile and separately report its integrated information. If included, include it for every profile and count the added elapsed time. Optimize a single fixed LO per waveform from the conditional-mean Gram matrix; do not silently allow time-varying LO for one candidate and fixed LO for another.

For wrong-state population, use the same orthonormal even/odd-cat logical projectors at storage alpha after return/recovery. Record the small coherent-input finite-alpha wrong-logical baseline and report raw values plus excess over a matched idle control. Keep leakage separate and never postselect by renormalizing code-space population.

## Validation promotion

Screen at24x8 only; promote baseline/frontier candidates to32x12 and40x14, increasing Na and Nb separately. Recheck pulse edges with halved save spacing and stricter solver tolerances; make discontinuities exact solver boundaries. Boundary populations are necessary but do not certify rare-rate convergence. Verify both codeword signs independently for every claimed winner.

At physical alpha2.1, report static rates only when converged in cutoff, shift, eigenvalue residual, relevant eigenmode overlap and mode multiplicity. Use small-alpha1.0/1.4 direct population fits to validate rate interpretation. Complex leading eigenvalues or multiple contributing modes invalidate a simple one-exponential switching claim. General complex pulse/circuit corrections can require the complete Hermitian operator representation, not the real antisymmetric sector.

For the final winner and tuned constant comparator, use amplitude +/-5%, phase +/-5deg, g2 +/-5%, and kappa_b +/-5% one at a time; then a small combined perturbation sample. Distinguish fixed nominal calibration from re-optimizing/recalibrating for every perturbation. Include corrected-circuit dynamics only after the ideal-model comparison is fair, and apply the same calibration assumptions to both protocols.

## Executed evidence reviewed

/tmp/cat-qubit-capstone/final_amp_metrics.json: equal-I amplified cycle I=.9999999992, read6.603850412us, cycle10.603850412us, wrong1.32194e-5, leakage8.10919e-6 at storage basis. QuTiP comparison in measurement-optimized-cycle.json agrees. These numbers describe existing pilots and do not establish a global shape optimum.

/tmp/cat-qubit-capstone/input_shape.json: one two-step shaper gives 0.666us complex settling versus0.968us original, but information4us=.035984264. Faster field settling does not establish faster useful measurement. It should remain an instructive supporting/negative result until compared at equal information.
